"""Offline tests using a fake provider (no network needed)."""
import time
import unittest
from converter import CachedRateProvider, CurrencyConverter, RateProvider, RateUnavailableError


class FakeProvider(RateProvider):
    def __init__(self):
        self.calls = 0
    def get_rate(self, base, target):
        self.calls += 1
        if target == "XXX":
            raise RateUnavailableError("no such currency")
        return {"INR": 83.0, "EUR": 0.9}.get(target, 1.0)


class Tests(unittest.TestCase):
    def test_convert(self):
        self.assertEqual(CurrencyConverter(FakeProvider()).convert(10, "usd", "inr"), 830.0)

    def test_cache_cuts_calls(self):
        fake = FakeProvider()
        c = CurrencyConverter(CachedRateProvider(fake, ttl_seconds=60))
        c.convert(1, "USD", "INR"); c.convert(5, "USD", "INR")
        self.assertEqual(fake.calls, 1)

    def test_cache_expiry(self):
        fake = FakeProvider()
        c = CurrencyConverter(CachedRateProvider(fake, ttl_seconds=0.05))
        c.convert(1, "USD", "INR"); time.sleep(0.1); c.convert(1, "USD", "INR")
        self.assertEqual(fake.calls, 2)

    def test_convert_many_partial_failure(self):
        res = CurrencyConverter(FakeProvider()).convert_many(100, "USD", ["INR", "EUR", "XXX"])
        self.assertEqual(res["INR"], 8300.0)
        self.assertEqual(res["EUR"], 90.0)
        self.assertIsInstance(res["XXX"], str)

    def test_validation(self):
        c = CurrencyConverter(FakeProvider())
        for args in [("abc", "USD", "INR"), (-5, "USD", "INR"), (1, "US", "INR")]:
            with self.assertRaises(ValueError):
                c.convert(*args)


if __name__ == "__main__":
    unittest.main()
