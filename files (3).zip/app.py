"""Tkinter GUI. Network calls run in worker threads so the window never freezes."""
import threading
import tkinter as tk
from tkinter import ttk

from converter import CurrencyConverter
from currencies import CURRENCIES

conv = CurrencyConverter()


def run_async(work, done):
    """Run `work` in a thread, then deliver the result on the Tk main thread."""
    def target():
        try:
            result, error = work(), None
        except Exception as exc:
            result, error = None, str(exc)
        root.after(0, lambda: done(result, error))
    threading.Thread(target=target, daemon=True).start()


def convert_one():
    status.set("Fetching rate...")
    amt, a, b = amount.get(), base.get(), target.get()
    run_async(lambda: conv.convert(amt, a, b),
              lambda r, e: status.set(e if e else f"{amt} {a.upper()} = {r:,.2f} {b.upper()}"))


def convert_many():
    status.set("Fetching rates concurrently...")
    amt, a = amount.get(), base.get()
    targets = [c for c in ("USD", "EUR", "GBP", "JPY", "AUD", "CAD", "AED", "SGD") if c != a.upper()]

    def done(res, err):
        if err:
            return status.set(err)
        out.delete("1.0", "end")
        for code, val in res.items():
            out.insert("end", f"{code}: {val:,.2f}\n" if isinstance(val, float) else f"{code}: {val}\n")
        status.set("Done")
    run_async(lambda: conv.convert_many(amt, a, targets), done)


root = tk.Tk()
root.title("Real-Time Currency Converter")
root.geometry("380x420")
f = ttk.Frame(root, padding=16)
f.pack(fill="both", expand=True)

amount, base, target, status = tk.StringVar(value="100"), tk.StringVar(value="USD"), tk.StringVar(value="INR"), tk.StringVar()
ttk.Label(f, text="Amount").pack(anchor="w")
ttk.Entry(f, textvariable=amount).pack(fill="x", pady=(0, 8))
ttk.Label(f, text="From").pack(anchor="w")
ttk.Combobox(f, textvariable=base, values=CURRENCIES).pack(fill="x", pady=(0, 8))
ttk.Label(f, text="To").pack(anchor="w")
ttk.Combobox(f, textvariable=target, values=CURRENCIES).pack(fill="x", pady=(0, 8))
ttk.Button(f, text="Convert", command=convert_one).pack(fill="x")
ttk.Button(f, text="Convert to 8 major currencies", command=convert_many).pack(fill="x", pady=6)
ttk.Label(f, textvariable=status, wraplength=340).pack(anchor="w", pady=4)
out = tk.Text(f, height=9, width=30)
out.pack(fill="both", expand=True)
root.mainloop()
