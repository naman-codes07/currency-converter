# Real-Time Currency Converter (Python)
    pip install -r requirements.txt
    python app.py              # GUI (needs tkinter, included with most Python installs)
    python test_converter.py   # offline unit tests

- `RateProvider` (abc) -> `LiveRateProvider` (Forex-Python, with timeout) and `CachedRateProvider` (TTL cache), both overriding `get_rate()`
- `convert_many()` fetches multiple currencies concurrently with threads; GUI calls run in worker threads so it never freezes
- Default arguments (`decimals=2`, default provider) replace method overloading
