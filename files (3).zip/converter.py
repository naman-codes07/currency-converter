"""Core logic: rate providers (abc), caching, and concurrent conversion."""
import threading
import time
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout


class RateUnavailableError(Exception):
    """Raised when a rate cannot be fetched (API failure, timeout, bad code)."""


class RateProvider(ABC):
    """Abstract base class: every provider must implement get_rate()."""

    @abstractmethod
    def get_rate(self, base: str, target: str) -> float:
        ...


class LiveRateProvider(RateProvider):
    """Fetches live rates through the Forex-Python library, with a timeout."""

    def __init__(self, timeout: float = 8.0):
        from forex_python.converter import CurrencyRates  # lazy import
        self._rates = CurrencyRates()
        self._timeout = timeout
        self._pool = ThreadPoolExecutor(max_workers=4)

    def get_rate(self, base: str, target: str) -> float:
        if base == target:
            return 1.0
        future = self._pool.submit(self._rates.get_rate, base, target)
        try:
            return float(future.result(timeout=self._timeout))
        except FutureTimeout:
            raise RateUnavailableError(f"Timed out fetching {base}->{target}")
        except Exception as exc:  # RatesNotAvailableError, network errors, ...
            raise RateUnavailableError(f"Could not get {base}->{target}: {exc}")


class CachedRateProvider(RateProvider):
    """Wraps another provider and caches recent rates to cut API calls."""

    def __init__(self, source: RateProvider, ttl_seconds: float = 300):
        self._source = source
        self._ttl = ttl_seconds
        self._cache = {}
        self._lock = threading.Lock()

    def get_rate(self, base: str, target: str) -> float:
        key = (base, target)
        now = time.monotonic()
        with self._lock:
            hit = self._cache.get(key)
            if hit and now - hit[1] < self._ttl:
                return hit[0]
        rate = self._source.get_rate(base, target)  # network call outside the lock
        with self._lock:
            self._cache[key] = (rate, now)
        return rate


class CurrencyConverter:
    def __init__(self, provider: RateProvider = None):
        # Default argument: use cached live rates unless another provider is given.
        self.provider = provider or CachedRateProvider(LiveRateProvider())

    @staticmethod
    def _clean(code: str) -> str:
        code = (code or "").strip().upper()
        if len(code) != 3 or not code.isalpha():
            raise ValueError(f"Invalid currency code: '{code}'")
        return code

    def convert(self, amount, base, target, decimals: int = 2) -> float:
        """Default argument `decimals` stands in for method overloading."""
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            raise ValueError("Amount must be a number")
        if amount < 0:
            raise ValueError("Amount cannot be negative")
        rate = self.provider.get_rate(self._clean(base), self._clean(target))
        return round(amount * rate, decimals)

    def convert_many(self, amount, base, targets, decimals: int = 2) -> dict:
        """Fetch several currencies concurrently; failures are reported per currency."""
        results = {}
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = {t: pool.submit(self.convert, amount, base, t, decimals) for t in targets}
            for code, fut in futures.items():
                try:
                    results[code] = fut.result()
                except (RateUnavailableError, ValueError) as exc:
                    results[code] = str(exc)
        return results
